package com.thelocal.serverslides;

import android.net.Uri;
import android.text.TextUtils;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import com.getcapacitor.Bridge;
import com.getcapacitor.BridgeWebViewClient;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Grafana sends "X-Frame-Options: deny" unless allow_embedding is switched on,
 * which stops a dashboard from showing inside the app's slides. For Grafana pages
 * loaded inside a slide (never the app itself), this fetches the page and drops that
 * one header, so no Grafana settings need to change. Cookies are shared with the
 * WebView through Capacitor's cookie manager, so the Grafana login carries over.
 */
public class FrameFriendlyClient extends BridgeWebViewClient {
    private final Bridge bridge;

    public FrameFriendlyClient(Bridge bridge) {
        super(bridge);
        this.bridge = bridge;
    }

    @Override
    public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
        try {
            Uri u = request.getUrl();
            String scheme = u.getScheme();
            String host = u.getHost();
            Map<String, String> h = request.getRequestHeaders();
            String accept = h == null ? null : (h.containsKey("Accept") ? h.get("Accept") : h.get("accept"));
            boolean isFramePage = !request.isForMainFrame()
                && "GET".equalsIgnoreCase(request.getMethod())
                && ("http".equals(scheme) || "https".equals(scheme))
                && host != null && !host.equalsIgnoreCase(bridge.getHost())
                && accept != null && accept.contains("text/html");
            if (isFramePage) {
                WebResourceResponse r = fetchFramePage(request);
                if (r != null) return r;
            }
        } catch (Exception ignored) {
            // fall back to the normal WebView behaviour
        }
        return super.shouldInterceptRequest(view, request);
    }

    private WebResourceResponse fetchFramePage(WebResourceRequest request) throws Exception {
        String url = request.getUrl().toString();
        HttpURLConnection c = null;
        int hops = 0;
        while (true) {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(15000);
            c.setReadTimeout(30000);
            Map<String, String> headers = request.getRequestHeaders();
            if (headers != null) {
                for (Map.Entry<String, String> e : headers.entrySet()) {
                    String k = e.getKey();
                    if (k == null || k.equalsIgnoreCase("Accept-Encoding") || k.equalsIgnoreCase("Cookie")) continue;
                    c.setRequestProperty(k, e.getValue());
                }
            }
            int code = c.getResponseCode(); // cookies are sent and stored by Capacitor's CookieHandler
            if (code >= 300 && code < 400 && hops++ < 5) {
                String loc = c.getHeaderField("Location");
                if (loc == null) break;
                url = new URL(new URL(url), loc).toString();
                c.disconnect();
                continue;
            }
            break;
        }

        int code = c.getResponseCode();
        if (code >= 300 && code < 400) return null;
        String mime = "text/html";
        String enc = "utf-8";
        String ct = c.getContentType();
        if (ct != null) {
            String[] parts = ct.split(";");
            mime = parts[0].trim();
            for (String p : parts) {
                String t = p.trim();
                if (t.toLowerCase(Locale.ROOT).startsWith("charset=")) enc = t.substring(8).replace("\"", "").trim();
            }
        }
        Map<String, String> out = new HashMap<>();
        for (Map.Entry<String, List<String>> e : c.getHeaderFields().entrySet()) {
            String k = e.getKey();
            if (k == null) continue;
            String kl = k.toLowerCase(Locale.ROOT);
            if (kl.equals("x-frame-options") || kl.equals("set-cookie") || kl.equals("content-length")
                || kl.equals("content-encoding") || kl.equals("transfer-encoding") || kl.equals("content-type")) continue;
            String v = TextUtils.join(", ", e.getValue());
            if (kl.equals("content-security-policy")) v = v.replaceAll("(?i)frame-ancestors[^;]*;?", "");
            out.put(k, v);
        }
        String reason = c.getResponseMessage();
        if (reason == null || reason.trim().isEmpty()) reason = code < 400 ? "OK" : "Error";
        InputStream body = code >= 400 ? c.getErrorStream() : c.getInputStream();
        if (body == null) body = new ByteArrayInputStream(new byte[0]);
        return new WebResourceResponse(mime, enc, code, reason, out, body);
    }
}
