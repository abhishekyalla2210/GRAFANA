package com.thelocal.serverslides;

import android.os.Bundle;
import android.webkit.CookieManager;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Grafana logins made by the app are shared with the dashboards shown in the slides
        CookieManager cookies = CookieManager.getInstance();
        cookies.setAcceptCookie(true);
        cookies.setAcceptThirdPartyCookies(getBridge().getWebView(), true);
        // Lets Grafana dashboards appear inside the slides (Grafana blocks framing by default)
        getBridge().setWebViewClient(new FrameFriendlyClient(getBridge()));
    }
}
