/* Server Slides on Android: the same window.slides API the desktop app provides,
   built on Capacitor. Grafana calls go through native HTTP (no CORS limits) and share
   cookies with the dashboards shown in the slides. */
(function () {
  const X = window.capacitorExports;
  if (!X || !X.Capacitor.isNativePlatform()) return;
  const { CapacitorHttp, CapacitorCookies, registerPlugin } = X;
  const LocalNotifications = registerPlugin("LocalNotifications");
  const App = registerPlugin("App");
  let gotoFn = null;

  /* ---------- Grafana logins, encrypted on the phone ----------
     An AES key is created once and kept in IndexedDB as non-extractable,
     so the saved passwords can only be decrypted by this app on this phone. */
  const CRED_KEY = "ss-grafana-logins";
  function idb() {
    return new Promise((res, rej) => {
      const r = indexedDB.open("ss-keys", 1);
      r.onupgradeneeded = () => r.result.createObjectStore("k");
      r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error);
    });
  }
  async function aesKey() {
    const db = await idb();
    const got = await new Promise(res => { const q = db.transaction("k").objectStore("k").get("main"); q.onsuccess = () => res(q.result); q.onerror = () => res(null); });
    if (got) return got;
    const key = await crypto.subtle.generateKey({ name: "AES-GCM", length: 256 }, false, ["encrypt", "decrypt"]);
    await new Promise(res => { const t = db.transaction("k", "readwrite"); t.objectStore("k").put(key, "main"); t.oncomplete = res; t.onerror = res; });
    return key;
  }
  const b64 = buf => btoa(String.fromCharCode(...new Uint8Array(buf)));
  const unb64 = s => Uint8Array.from(atob(s), c => c.charCodeAt(0));
  async function readLogins() {
    try {
      const raw = localStorage.getItem(CRED_KEY); if (!raw) return {};
      const { iv, ct } = JSON.parse(raw);
      const plain = await crypto.subtle.decrypt({ name: "AES-GCM", iv: unb64(iv) }, await aesKey(), unb64(ct));
      return JSON.parse(new TextDecoder().decode(plain)) || {};
    } catch (e) { return {}; }
  }
  async function writeLogins(map) {
    try {
      const iv = crypto.getRandomValues(new Uint8Array(12));
      const ct = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, await aesKey(), new TextEncoder().encode(JSON.stringify(map)));
      localStorage.setItem(CRED_KEY, JSON.stringify({ iv: b64(iv), ct: b64(ct) }));
    } catch (e) {}
  }

  /* ---------- Grafana HTTP ---------- */
  function normalizeBase(input) {
    let s = String(input || "").trim();
    if (!s) return "";
    if (!/^https?:\/\//i.test(s)) s = "https://" + s;
    try { const u = new URL(s); return u.origin + u.pathname.replace(/\/(d|d-solo|dashboards|dashboard|explore|login|playlists|alerting)(\/.*)?$/, "").replace(/\/$/, ""); }
    catch (e) { return ""; }
  }
  const hostOf = b => { try { return new URL(b).host; } catch (e) { return b; } };
  async function request(base, method, path, body, token) {
    const headers = { Accept: "application/json" };
    if (body) headers["Content-Type"] = "application/json";
    if (token) headers.Authorization = "Bearer " + token;
    const r = await CapacitorHttp.request({ url: base + path, method, headers, data: body, connectTimeout: 15000, readTimeout: 20000 });
    let json = r.data;
    if (typeof json === "string") { try { json = JSON.parse(json); } catch (e) { json = null; } }
    return { status: r.status, json };
  }
  async function whoAmI(base) {
    const r = await request(base, "GET", "/api/user");
    return r.status === 200 && r.json && r.json.login ? { login: r.json.login, name: r.json.name || r.json.login } : null;
  }
  async function doLogin(base, user, password) {
    let r;
    try { r = await request(base, "POST", "/login", { user, password }); }
    catch (e) {
      const cert = /cert|ssl|trust/i.test(String(e && e.message));
      return { ok: false, error: cert ? `${hostOf(base)} uses a security certificate this phone doesn't trust. Ask IT to install the company certificate on the phone.`
                                      : `Couldn't reach ${hostOf(base)}. Check the link and that the phone is on the company network or VPN.` };
    }
    if (r.status === 401) return { ok: false, error: "Wrong username or password." };
    if (r.status === 429) return { ok: false, error: "Too many attempts. Grafana has locked logins for a few minutes; try again shortly." };
    if (r.status !== 200) return { ok: false, error: (r.json && r.json.message) || `Grafana answered ${r.status}.` };
    const me = await whoAmI(base).catch(() => null);
    if (!me) return { ok: false, error: "Grafana accepted the password but didn't keep the session. Ask your Grafana admin whether cookie_secure is set while the site runs on http." };
    return { ok: true, user: me };
  }
  async function reloginFor(base) {
    const l = (await readLogins())[base];
    return l ? (await doLogin(base, l.user, l.password)).ok : false;
  }

  /* ---------- the slides themselves: the Grafana page in a frame ---------- */
  function renderSlide(el, s) {
    const url = typeof buildUrl === "function" ? buildUrl(s.url) : s.url;
    el.innerHTML = "";
    const f = document.createElement("iframe");
    f.src = url;
    f.title = s.name + " dashboard";
    f.setAttribute("allow", "fullscreen; clipboard-write");
    f.style.cssText = "width:100%;height:100%;border:0;display:block;background:#111217";
    el.appendChild(f);
  }

  /* ---------- open links in the phone's browser ---------- */
  window.open = url => { if (/^https?:/i.test(String(url))) window.location.href = url; return null; };
  document.addEventListener("click", e => {
    const a = e.target.closest && e.target.closest('a[target="_blank"]');
    if (a && /^https?:/i.test(a.href)) { e.preventDefault(); window.location.href = a.href; }
  }, true);

  /* ---------- notifications ---------- */
  let nid = 1;
  LocalNotifications.requestPermissions().catch(() => {});
  LocalNotifications.addListener("localNotificationActionPerformed", e => {
    const name = e && e.notification && e.notification.extra && e.notification.extra.server;
    if (name && gotoFn) gotoFn(name);
  });

  /* ---------- Android back button ---------- */
  App.addListener("backButton", () => {
    const open = document.querySelector("dialog[open]");
    if (open) { open.close(); return; }
    if (typeof setView === "function" && typeof view !== "undefined") {
      if (view === "chan") { setView(typeof isPhone === "function" && isPhone() ? "home" : "globe"); return; }
      if (view !== "globe") { setView("globe"); return; }
    }
    App.exitApp();
  });

  window.slides = {
    platform: "android",
    renderSlide,
    onNav() {},
    onGoTo(fn) { gotoFn = fn; },
    notify({ title, body, server }) {
      LocalNotifications.schedule({ notifications: [{ id: (nid++ % 100000) + 1, title, body, extra: { server } }] }).catch(() => {});
    },
    async grafanaGet(input, path) {
      const base = normalizeBase(input);
      if (!/^\/api\//.test(path)) throw new Error("Only Grafana API paths are allowed.");
      let r = await request(base, "GET", path);
      if (r.status === 401 && await reloginFor(base)) r = await request(base, "GET", path);
      if (r.status === 401) { const e = new Error(`Log in to ${hostOf(base)} again.`); e.code = 401; throw e; }
      if (r.status === 403) throw new Error("Your Grafana user isn't allowed to read this.");
      if (r.status !== 200) throw new Error((r.json && r.json.message) || ("Grafana answered " + r.status));
      return r.json;
    },
    async queryRam({ base: input, dsUid, expr, token }) {
      const base = normalizeBase(input);
      const body = { from: "now-5m", to: "now", queries: [{ refId: "A", datasource: { uid: dsUid }, expr, instant: true, range: false, intervalMs: 15000, maxDataPoints: 1 }] };
      let r = await request(base, "POST", "/api/ds/query", body, token);
      if (r.status === 401 && !token && await reloginFor(base)) r = await request(base, "POST", "/api/ds/query", body);
      if (r.status === 401) throw new Error(`log in to ${hostOf(base)} again`);
      if (r.status !== 200) throw new Error("Grafana answered " + r.status + (r.json && r.json.message ? ": " + r.json.message : ""));
      const result = r.json && r.json.results && r.json.results.A;
      if (result && result.error) throw new Error(result.error);
      const out = [];
      for (const frame of (result && result.frames) || []) {
        const fields = frame.schema.fields, values = frame.data.values;
        fields.forEach((f, i) => {
          if (f.type !== "number") return;
          const col = values[i] || [], v = col[col.length - 1];
          if (typeof v === "number") out.push({ labels: f.labels || {}, value: v });
        });
      }
      return out;
    },
    auth: {
      async status(input) {
        const base = normalizeBase(input);
        if (!base) return { ok: false };
        try { const me = await whoAmI(base); return me ? { ok: true, user: me, base } : { ok: false, base }; }
        catch (e) { return { ok: false, base, offline: true, error: String(e && e.message) }; }
      },
      async login({ base: input, user, password, remember }) {
        const base = normalizeBase(input);
        if (!base) return { ok: false, error: "That doesn't look like a Grafana address." };
        const res = await doLogin(base, user, password);
        if (res.ok) {
          const map = await readLogins();
          if (remember !== false) map[base] = { user, password }; else delete map[base];
          await writeLogins(map);
          res.base = base;
        }
        return res;
      },
      async relogin(input) {
        const base = normalizeBase(input);
        const l = (await readLogins())[base];
        if (!l) return { ok: false, base };
        return Object.assign(await doLogin(base, l.user, l.password), { base });
      },
      async saved() { return Object.entries(await readLogins()).map(([base, l]) => ({ base, user: l.user })); },
      async forget(input) {
        const base = normalizeBase(input);
        const map = await readLogins(); delete map[base]; await writeLogins(map);
        try { await request(base, "GET", "/logout"); } catch (e) {}
        try { await CapacitorCookies.clearCookies({ url: base }); } catch (e) {}
        return { ok: true };
      },
      async logout(input) { return this.forget(input); }
    }
  };
})();
